package com.bastiangperez.bgp_conversor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ListActivity extends AppCompatActivity {

    Button bgp_goBack;
    ListView bgp_ExchangesListView;

    int bgp_flags[] = {R.drawable.eu,R.drawable.us,R.drawable.jp, R.drawable.bg, R.drawable.cz, R.drawable.dk, R.drawable.gb, R.drawable.hu,
            R.drawable.pl, R.drawable.ro, R.drawable.se, R.drawable.ch, R.drawable.ice, R.drawable.no, R.drawable.cro, R.drawable.ru, R.drawable.tr,
            R.drawable.au, R.drawable.br, R.drawable.ca, R.drawable.cn, R.drawable.hk, R.drawable.id, R.drawable.il, R.drawable.in, R.drawable.kr,
            R.drawable.mx, R.drawable.my, R.drawable.nz, R.drawable.ph, R.drawable.sg, R.drawable.th, R.drawable.za};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        //Creamos los binding de la vista
        bgp_goBack = findViewById(R.id.btnVolver);
        bgp_ExchangesListView = findViewById(R.id.lvExchanges);

        //Definimos el adaptador que nos mostrará el listView.
         //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, MainActivity.bgp_currencyRatioArray);
         CustomlistViewAdapter adapter2 = new CustomlistViewAdapter(this, bgp_flags, MainActivity.bgp_currencyRatioArray);
        bgp_ExchangesListView.setAdapter(adapter2);

        //Llamamos a la función que controla el botón que nos permitirá volver a la pantalla inicial.
        setupGoBack();
    }

    private void setupGoBack() {
        bgp_goBack.setOnClickListener(view -> {
            Intent goBack = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(goBack);
        });
    }
}