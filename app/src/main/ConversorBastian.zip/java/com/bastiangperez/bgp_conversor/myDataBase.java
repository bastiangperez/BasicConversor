package com.bastiangperez.bgp_conversor;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class myDataBase extends SQLiteOpenHelper {
    public static final int DB_VERSION = 1;
    //El archivo por defecto se guardará en  /data/data/com.bastiangperez.bgp_conversor/databases/Currencies.db
    public static final String DB_NAME = "currencies.db";


    public myDataBase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table currencies(id int primary key, currency text, ratio text)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table currencies");
        onCreate(sqLiteDatabase);
    }
}
