package com.bastiangperez.bgp_conversor;


import androidx.appcompat.app.AppCompatActivity;

public class prueba extends AppCompatActivity {
   /* Spinner spin1_onm; // primer spinner para cargar las divisas
    Spinner spin2_onm; // segundo spinner para cargar las divisas
    TextView tResult_onm; // dónde mostramos el resultado

    public  static String[] currency_onm; // Array que cargaremos con los literales de las divisas
    public  static String[] ratio_onm;    // Array que cargaremos con los importes de cambio de las divisas
    public  static String[] monedaValor_onm;
    Cursor cur_onm;
    int tamano_onm= 0;
    BbddDivisas admin_onm;
    private CustomAdapter adapter_onm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spin1_onm = findViewById(R.id.spinDivisas); // inicializamos el spinner
        spin2_onm = findViewById(R.id.spinADivisas2); // inicializamos el spinner


        // Hay que crearse un hilo porque estamos utilizando la clase DocumentBuilderFactory y da error si no lo hacemos
        new Thread(new Runnable() {
            boolean conexion_onm = false;
            String contador_onm = null;

            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public synchronized void run() {
                try {
                    // me creo un objeto de la bbdd y abrimos una conexión
                    *//* parámetros:
                        context: dónde va a ser válido, en este caso es en esta actividad, entonces this
                        name: nombre de la bbdd, el que queramos
                        factory: objetos que permiten crearnos cursores sobre la bbdd, con null se coge la implementación por defecto para el cursor
                        versión, si la bbdd no existe la creará y si existe me dejará conectarme.
                     *//*
                    admin_onm = new BbddDivisas(MainActivity.this, "Administracion", null, 1);
                    //obtenemos la conexión de solo lectura
                    SQLiteDatabase bbdd_onm = admin_onm.getReadableDatabase();
                    // Obtenemos las distintas conexiones del emulador
                    ConnectivityManager conMan_onm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo[] infoNet_onm = conMan_onm.getAllNetworkInfo();
                    // Nos recorremos las distintas conexiones
                    for (NetworkInfo i : infoNet_onm) {
                        // Si es WIFI
                        if (i.getTypeName().equalsIgnoreCase("WIFI")) {

                            //if (!i.isConnected()) { // PARA HACER LA PRUEBA LO DEJAMOS COMENTADO PARA QUE ENTRE
                            if (i.isConnected()) {
                                // si tiene conexión a internet queremos que el spinner lo cargue con la url
                                conexion_onm = true;
                            } else {
                                // No tiene conexión a internet, cargamos el spinner con los datos de la bbdd.
                                conexion_onm = false;

                                // Mostramos una alerta para avisar de que está sin internet.
                                //Builder alerta_onm = new Builder(MainActivity.this);
                                //alerta_onm.setMessage("Usted está sin conexión a internet, tomaremos los datos de la última ejecución del programa").show();
                                //alerta_onm.setMessage("Usted está sin conexión a internet, tomaremos los datos de la última ejecución del programa").show();
                                //System.out.println("Usted está sin conexión a internet, tomaremos los datos de la última ejecución del programa");
                                // Nos creamos una consulta para saber el número de registros que hay en la tabla
                                contador_onm = "select count(*) from divisas";
                                tamano_onm = (int) DatabaseUtils.longForQuery(bbdd_onm, contador_onm, null);
                                // inicializamos los arrays.
                                currency_onm = new String[tamano_onm];
                                ratio_onm = new String[tamano_onm];
                                monedaValor_onm = new String[tamano_onm];
                                // Obtnemos las monedas y sus valores
                                String consulta_onm = "select * from divisas";
                                // como me devuelve más de un registro, monto un cursor.
                                // el null  es para indicar que no necesita parámetros
                                cur_onm = bbdd_onm.rawQuery(consulta_onm, null);
                                // Recorremos el cursor
                                String moneda_onm;
                                String valorMoneda_onm;
                                // Comprobamos si nos devuelve registros
                                if (cur_onm.moveToFirst()) {
                                    int k = 0; // para ir aumentando la posición del array
                                    while (cur_onm.moveToNext()) {
                                        // Obtenemos los datos de la tabla
                                        moneda_onm = cur_onm.getString(cur_onm.getColumnIndex("divisa"));
                                        valorMoneda_onm = cur_onm.getString(cur_onm.getColumnIndex("valor"));
                                        // como no hay conexión con la bbdd, cargamos los array con lo almacenado
                                        currency_onm[k] = moneda_onm;
                                        ratio_onm[k] = valorMoneda_onm;
                                        monedaValor_onm[k] = "Divisa: " + moneda_onm + " Valor: " + valorMoneda_onm;
                                        k++;
                                    }
                                }
                                // cerramos el cursor.
                                cur_onm.close();
                            }
                        }
                    }
                    //cerramos la conexión a la bbdd
                    bbdd_onm.close();

                    bbdd_onm = admin_onm.getReadableDatabase();
                    String consulta_onm = "select * from divisas";
                    // como me devuelve más de un registro, monto un cursor.
                    // el null  es para indicar que no necesita parámetros
                    //Cursor
                    cur_onm = bbdd_onm.rawQuery(consulta_onm, null);
                    // Recorremos el cursor
                    String moneda_onm;
                    String valorMoneda_onm;


                    // Comprobamos si nos devuelve registros
                    if (cur_onm.moveToFirst()) {
                        //int k = 0; // para ir aumentando la posición del array
                        while (cur_onm.moveToNext()) {
                            // Obtenemos los datos de la tabla
                            moneda_onm = cur_onm.getString(cur_onm.getColumnIndex("divisa"));
                            valorMoneda_onm = cur_onm.getString(cur_onm.getColumnIndex("valor"));
                            System.out.println("Moneda: " + moneda_onm);
                            System.out.println("Valor: " + valorMoneda_onm);
                        }
                    }

                    // cerramos el cursor
                    cur_onm.close();


                    // Si no tenemos conexión, los arrays para cargar los spinner ya se han cargado con los
                    // datos de la bbdd, no tenemos que descargarlos de la url.
                    // Si tenemos conexión, descargamos los datos de la url.
                    if (conexion_onm) {

                        // Nos creamos una instancia de DOM para obtener el xml de internet y parsearlo
                        DocumentBuilderFactory dbf_onm = DocumentBuilderFactory.newInstance();
                        DocumentBuilder db_onm = dbf_onm.newDocumentBuilder();
                        Document doc_onm = db_onm.parse(new
                                URL("https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml ").openStream());

                        // Comprobamos si está relleno el documento
                        if (doc_onm == null) {
                            // Si no está relleno, mostramos error.
                            Toast notification_onm = Toast.makeText(MainActivity.this, "error", Toast.LENGTH_SHORT);
                            notification_onm.show();
                        }
                       *//* La url nos devuelve un xml del tipo
                            <Cube>
                                <Cube time="2021-10-29">
                                    <Cube currency="USD" rate="1.1645"/>
                                    <Cube currency="JPY" rate="132.62"/>
                                </Cube>
                            </Cube>   *//*

                        // Buscamos la etiqueta principal dentro del xml llamada "Cube" y el resultado lo
                        // guardamos en una lista de nodos que nos iremos recorriendo para obtener la información
                        // Retorna una lista de la clase NodeList que contiene todos los nodos hijo de este nodo.
                        // Si no hay nodos hijo, la lista estará vacía.
                        // getElementsByTagName: devuelve un NodeList con los elementos de un determinado tipo.
                        NodeList namelist = doc_onm.getElementsByTagName("Cube");

                        tamano_onm = 0;
                        String curren_onm; // variable que contendrá el valor del texto de la moneda.

                        // obtenemos el tamaño del nodelist, nos lo tenemos que recorrer para saber si algún
                        // nodo viene vacío, en ese caso, no lo contaremos.
                        for (int i = 0; i < namelist.getLength(); i++) {
                            // Obtenemos el nodo
                            Node nodo_onm = namelist.item(i);
                            Element ele_onm = (Element) nodo_onm;
                            // Obtenemos el valor de currency del xml.
                            curren_onm = ele_onm.getAttribute("currency");
                            // comprobamos si viene o no vacío.
                            // Si viene relleno, sumamos uno al contador.
                            if (!curren_onm.equals("")) {
                                tamano_onm++;
                            }
                        }
                        // Inicializamos los array con el tamaño del número de nodos obtenidos
                        currency_onm = new String[tamano_onm];
                        ratio_onm = new String[tamano_onm];
                        monedaValor_onm = new String[tamano_onm];

                        //vuelvo el contador a cero para reutilizarlo
                        tamano_onm = 0;
                        String cantidad_onm;

                        // Abrimos una conexión con la bbdd para insertar los nuevos valores del xml
                        //admin_onm = new BbddDivisas(MainActivity.this,"Administracion",null,1);
                        //obtenemos la conexión de solo lectura
                        //bbdd_onm = admin_onm.getReadableDatabase();
                        bbdd_onm = admin_onm.getWritableDatabase(); // para que pueda escribir en la bbdd
                        // eliminamos la tabla y la volvemo a crear.
                        admin_onm.onUpgrade(bbdd_onm, 1, 2);
                        // Nos recorremos los nodos obtenidos
                        for (int i = 0; i < namelist.getLength(); i++) {
                            // Obtenemos el nodo
                            Node nodo_onm = namelist.item(i);
                            // obtenemos el elemento
                            Element ele_onm = (Element) nodo_onm;
                            // Obtenemos las iniciales y la cantidad de la divisa(currency)
                            curren_onm = ele_onm.getAttribute("currency");
                            cantidad_onm = ele_onm.getAttribute("rate");
                            // comprobamos si viene relleno.
                            if (!curren_onm.equals("")) {

                                // Añadimos las divisas y la cantidad a sus respectivos arrays.
                                currency_onm[tamano_onm] = curren_onm;
                                ratio_onm[tamano_onm] = cantidad_onm;
                                monedaValor_onm[tamano_onm] = "Divisa: " + curren_onm + " Valor: " + cantidad_onm;
                                // sumamos 1 a la posición en j para que sume una posicion en el array
                                tamano_onm++;
                                // Guardamos en la bbdd los valores
                                ContentValues registro_onm = new ContentValues();
                                registro_onm.put("id", tamano_onm);
                                registro_onm.put("divisa", curren_onm);
                                registro_onm.put("valor", cantidad_onm);
                                bbdd_onm.insert("divisas", null, registro_onm);
                            }
                        }
                    }
                        *//*
                        String consulta_onm = "select * from divisas";
                        // como me devuelve más de un registro, monto un cursor.
                        // el null  es para indicar que no necesita parámetros
                        //Cursor
                        cur_onm = bbdd_onm.rawQuery(consulta_onm, null);
                        // Recorremos el cursor
                        String moneda_onm;
                        String valorMoneda_onm;


                        // Comprobamos si nos devuelve registros
                        if (cur_onm.moveToFirst()) {
                            //int k = 0; // para ir aumentando la posición del array
                            while (cur_onm.moveToNext()) {
                                // Obtenemos los datos de la tabla
                                moneda_onm = cur_onm.getString(cur_onm.getColumnIndex("divisa"));
                                valorMoneda_onm = cur_onm.getString(cur_onm.getColumnIndex("valor"));
                                System.out.println("Moneda: " + moneda_onm);
                                System.out.println("Valor: " + valorMoneda_onm);
                            }
                        }

                        // cerramos el cursor
                        cur_onm.close();

                         *//*
                    // cerrramos la conexión a la bbdd.
                    admin_onm.close();
                    //}
                } catch(Exception e){
                    //                    cur_onm.close();
                    // cerrramos la conexión a la bbdd.
                    admin_onm.close();
                    e.printStackTrace();
                }
            }

        }).start();

        try {
            while (currency_onm == null) {
                Thread.sleep(200);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // cargamos los spinner
        String[] divisasI_onm = {"EUR - Euro","USD - Dólar estadounidense","JPY - Yen japonés","BGN - Lev búlgaro","CZK - Corona checa","DKK - Corona danesa",
                "GBP - Libra esterlina","HUF - Forinto","PLN - Złoty","RON - Leu rumano","SEK - Corona sueca","CHF - Franco suizo",
                "ISK - Corona islandesa","NOK - Corona noruega","HRK - Kuna","RUB - Rublo ruso","TRY - Lira turca","AUD - Dólar australiano",
                "BRL - Real brasileño","CAD - Dólar canadiense","CNY - Yuan chino","HKD - Dólar de Hong Kong","IDR - Rupia indonesia",
                "ILS - Nuevo séquel israelí","INR - Rupia india","KRW - Won","MXN - Peso mexicano","MYR - Ringgit malayo",
                "NZD - Dólar neozelandés","PHP - Peso filipino","SGD - Dólar de Singapur","THB - Baht","ZAR - Rand" };
        // Array formado por las imágenes de las banderas
        int[] banderas_onm = {R.drawable.eur, R.drawable.usd, R.drawable.jpy, R.drawable.bgn,R.drawable.czk,R.drawable.dkk,R.drawable.gbp,
                R.drawable.huf,R.drawable.pln,R.drawable.ron,R.drawable.sek,R.drawable.chf,R.drawable.isk,R.drawable.nok,
                R.drawable.hrk,R.drawable.rub,R.drawable.trye,R.drawable.aud,R.drawable.brl,R.drawable.cad,R.drawable.cny,
                R.drawable.hkd,R.drawable.idr,R.drawable.ils,R.drawable.inr,R.drawable.krw,R.drawable.mxn,R.drawable.myr,
                R.drawable.nzd,R.drawable.php,R.drawable.sgd,R.drawable.thb,R.drawable.zar};



        //int[] banderas_rla = {R.drawable.unionEuropea, R.drawable.usa,R.drawable.gbp, R.drawable.inr, R.drawable.chf, R.drawable.jpy, R.drawable.mxn, R.drawable.sek,
        //      R.drawable.rub, R.drawable.krw, R.drawable.thb};

        //String p;
        //String texto_onm;

        String[] iniciales = new String[tamano_onm];
        int[] banderas = new int[tamano_onm];
        int j = 1;

        for (int i = 0; i < divisasI_onm.length; i++) {
            // Metemos el Euro.
            iniciales[j] = divisasI_onm[0];
            banderas[j] = banderas_onm[0];
            //.equals(currency_onm[i]);
            if(divisasI_onm[i].substring(0,3).equalsIgnoreCase(currency_onm[i])){
                // si coinciden las monedas que hemos puesto en el array como modelo y lo que nos ha devuelto internet.
                iniciales[j] = divisasI_onm[i];
                banderas[j] = banderas_onm[i];
                // Enlaza el formato del CustomAdapter con cada spinner
                j++;
            }
        }
        adapter_onm = new CustomAdapter(this, iniciales,banderas);
        spin1_onm.setAdapter(adapter_onm);
        spin2_onm.setAdapter(adapter_onm);



     *//*   ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, currency_onm);
        // lo cargamos en los dos spinner
        spin1_onm.setAdapter(adaptador);
        spin2_onm.setAdapter(adaptador);
*/
    }
